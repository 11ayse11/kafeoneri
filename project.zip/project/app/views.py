#from flask import Flask
#from flask import render_template



#app=Flask(__name__)

#@app.route("/")
#def Index():
   # return render_template("index.html")

from flask import Flask, render_template, redirect, url_for
from flask import request

app = Flask(__name__)

# Anasayfa yönlendirmesi
@app.route('/')
def home():
    return render_template('index.html')


@app.route('/test')
def test_harita():
    return render_template('test.html')


# Giriş sayfası yönlendirmesi
@app.route('/login')
def login():
    return render_template('login.html')  # Burada giriş sayfası olacak



def get_top_10_keywords():
    # Burada sabit olarak belirttiğiniz en sık kullanılan 10 kelimeyi listeliyoruz
    return [
        "place", "nice", "service", "malatya", "good", "price", "coffee", "time", "go", "like"
    ]

@app.route('/detay', methods=['GET', 'POST'])
def detay():
    keywords = get_top_10_keywords()  # En sık kullanılan 10 kelimeyi alıyoruz
    if request.method == 'POST':
        comment = request.form['comment']
        rating = request.form['rating']
        # Burada formdan gelen yorum ve puan bilgilerini işleyebilirsiniz
        print(f"Yorum: {comment}, Puan: {rating}")
        return render_template('detay.html', keywords=keywords, comment=comment, rating=rating)
    return render_template('detay.html', keywords=keywords)






@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        # Burada kayıt işlemi yapılacak (örneğin, şifre kontrolü ve veritabanına kaydetme)
        if password != confirm_password:
            return "Şifreler uyuşmuyor!", 400
        print(f"Kayıt Olundu: {username}, Şifre: {password}")
        return redirect(url_for('login'))  # Kayıt başarılıysa giriş sayfasına yönlendirme
    return render_template('register.html')

if __name__ == '__main__':
    app.run(debug=True)
